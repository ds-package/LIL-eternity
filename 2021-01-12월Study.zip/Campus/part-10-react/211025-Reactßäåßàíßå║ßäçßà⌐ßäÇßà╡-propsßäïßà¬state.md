# Props 와 state

Props는 컴포넌트 외부에서 컴포넌트에게 주는 데이터

State는 컴포넌트 내부에서 변경할 수 있는 데이터

![image](./image/01.propsAndstate.png)
둘 다 변경이 발생하면, 랜더가 다시 일어날 수 있음

Render 함수

- Props와 State를 바탕으로 컴포넌트를 그린다.
  그리고, Props와 State가 변경되면, 컴포넌트를 다시 그린다.

- 컴포넌트를 그리는 방법을 기술하는 함수가 Render함수이다.

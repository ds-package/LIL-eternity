# TIL 작성규칙 : Jekyll

**<span style="color:#4886FF">TITLE</span>** : TIL{Date}\_{lowerCamelCase}

**<span style="color:#4886FF">FORM👇</span>**

```
오늘 배운 것 한 줄 정리
```

### **시도한 것**

```
ASIS CODE
```

```
TOBE CODE : 있다면 반드시 기록할 것 !
```

---

### **Reference**

<a href="https://www.notion.so/miniyoon/Minhee-Yoon-deca2ff59d4345119eed55b1ecb2d53a">
<img src="https://img.shields.io/badge/참고한 글의 출처와 링크 표기-000000?style=flat-square&logo=Notion&logoColor=white&link="/></a>

<a href="">
<img src="https://img.shields.io/badge/참고한 글의 출처와 링크 표기-4886FF?style=flat-square&logo=Facebook&logoColor=white&link="/></a>

<a href="">
<img src="https://img.shields.io/badge/참고한 글의 출처와 링크 표기-FF5700?style=flat-square&logo=Bloglovin&logoColor=white&link="/></a>

[아이콘참고 ~~작성 시 지울 것~~ ](https://simpleicons.org/)

# TIL 작성규칙 : JS

**<span style="color:#4886FF">TITLE</span>** : TIL{Date}\_{lowerCamelCase}

**<span style="color:#4886FF">FORM👇</span>**

```
오늘 배운 것 한 줄 정리
```

### **EX시도한 것**

![ex_image](./asset/image/ex_image.png)

```
ASIS CODE
```

```
TOBE CODE : 있다면 반드시 기록할 것 !
```

<p align="center">
  <img src="./asset/image/ex_image2.png" width="405" />
  <img src="./asset/image/ex_image2.png" width="405" />
  <br>*이미지 첨부 시 참고*
</p>
---

### **Reference**

<a href="https://www.notion.so/miniyoon/Minhee-Yoon-deca2ff59d4345119eed55b1ecb2d53a">
<img src="https://img.shields.io/badge/참고한 글의 출처와 링크 표기-000000?style=flat-square&logo=Notion&logoColor=white&link="/></a>

<a href="">
<img src="https://img.shields.io/badge/참고한 글의 출처와 링크 표기-4886FF?style=flat-square&logo=Facebook&logoColor=white&link="/></a>

<a href="">
<img src="https://img.shields.io/badge/참고한 글의 출처와 링크 표기-FF5700?style=flat-square&logo=Bloglovin&logoColor=white&link="/></a>

[아이콘참고 ~~작성 시 지울 것~~ ](https://simpleicons.org/)
